gdjs.Level_321Code = {};
gdjs.Level_321Code.GDGroundObjects1= [];
gdjs.Level_321Code.GDGroundObjects2= [];
gdjs.Level_321Code.GDGroundObjects3= [];
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects1= [];
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects2= [];
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects3= [];
gdjs.Level_321Code.GDGroundLeftEdgeObjects1= [];
gdjs.Level_321Code.GDGroundLeftEdgeObjects2= [];
gdjs.Level_321Code.GDGroundLeftEdgeObjects3= [];
gdjs.Level_321Code.GDGrass_95951Objects1= [];
gdjs.Level_321Code.GDGrass_95951Objects2= [];
gdjs.Level_321Code.GDGrass_95951Objects3= [];
gdjs.Level_321Code.GDGrassRightEdgeObjects1= [];
gdjs.Level_321Code.GDGrassRightEdgeObjects2= [];
gdjs.Level_321Code.GDGrassRightEdgeObjects3= [];
gdjs.Level_321Code.GDGrassLeftEdgeObjects1= [];
gdjs.Level_321Code.GDGrassLeftEdgeObjects2= [];
gdjs.Level_321Code.GDGrassLeftEdgeObjects3= [];
gdjs.Level_321Code.GDGroundBaseObjects1= [];
gdjs.Level_321Code.GDGroundBaseObjects2= [];
gdjs.Level_321Code.GDGroundBaseObjects3= [];
gdjs.Level_321Code.GDPlayer1Objects1= [];
gdjs.Level_321Code.GDPlayer1Objects2= [];
gdjs.Level_321Code.GDPlayer1Objects3= [];
gdjs.Level_321Code.GDNarrowLadderObjects1= [];
gdjs.Level_321Code.GDNarrowLadderObjects2= [];
gdjs.Level_321Code.GDNarrowLadderObjects3= [];
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects1= [];
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects2= [];
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects3= [];
gdjs.Level_321Code.GDSky_9595BaseObjects1= [];
gdjs.Level_321Code.GDSky_9595BaseObjects2= [];
gdjs.Level_321Code.GDSky_9595BaseObjects3= [];
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects1= [];
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects2= [];
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects3= [];
gdjs.Level_321Code.GDHealthObjects1= [];
gdjs.Level_321Code.GDHealthObjects2= [];
gdjs.Level_321Code.GDHealthObjects3= [];
gdjs.Level_321Code.GDNewTiledSpriteObjects1= [];
gdjs.Level_321Code.GDNewTiledSpriteObjects2= [];
gdjs.Level_321Code.GDNewTiledSpriteObjects3= [];
gdjs.Level_321Code.GDPixelHeartBarObjects1= [];
gdjs.Level_321Code.GDPixelHeartBarObjects2= [];
gdjs.Level_321Code.GDPixelHeartBarObjects3= [];
gdjs.Level_321Code.GDcheckpointObjects1= [];
gdjs.Level_321Code.GDcheckpointObjects2= [];
gdjs.Level_321Code.GDcheckpointObjects3= [];
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects1= [];
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects2= [];
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects3= [];
gdjs.Level_321Code.GDStrawberryObjects1= [];
gdjs.Level_321Code.GDStrawberryObjects2= [];
gdjs.Level_321Code.GDStrawberryObjects3= [];
gdjs.Level_321Code.GDBearTrapObjects1= [];
gdjs.Level_321Code.GDBearTrapObjects2= [];
gdjs.Level_321Code.GDBearTrapObjects3= [];
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects1= [];
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects2= [];
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects3= [];
gdjs.Level_321Code.GDBackgroundMountainsObjects1= [];
gdjs.Level_321Code.GDBackgroundMountainsObjects2= [];
gdjs.Level_321Code.GDBackgroundMountainsObjects3= [];
gdjs.Level_321Code.GDCloudsObjects1= [];
gdjs.Level_321Code.GDCloudsObjects2= [];
gdjs.Level_321Code.GDCloudsObjects3= [];
gdjs.Level_321Code.GDClouds2Objects1= [];
gdjs.Level_321Code.GDClouds2Objects2= [];
gdjs.Level_321Code.GDClouds2Objects3= [];
gdjs.Level_321Code.GDWoodGreenBarObjects1= [];
gdjs.Level_321Code.GDWoodGreenBarObjects2= [];
gdjs.Level_321Code.GDWoodGreenBarObjects3= [];


gdjs.Level_321Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "72e9c7d27d07ead77a928dacdf3947412c9aa607e22b3a94d26fa7f9412224ee_01 - super mushroom eater revised and fixed.aac", false, 15, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Level_321Code.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects2);
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects2[k] = gdjs.Level_321Code.GDPlayer1Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8414924);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayer1Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "01d787569bed7ee17859eca13499426a536d38b472d1480df36d5980ce635cfa_Powerup 5.aac", false, 20, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects2.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects2[k] = gdjs.Level_321Code.GDPlayer1Objects2[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9688876);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayer1Objects2 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects2.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects1.length;i<l;++i) {
    if ( !(gdjs.Level_321Code.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects1[k] = gdjs.Level_321Code.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects1.length;i<l;++i) {
    if ( !(gdjs.Level_321Code.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects1[k] = gdjs.Level_321Code.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects1[k] = gdjs.Level_321Code.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10803660);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.Level_321Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level_321Code.GDPlayer1Objects2.length !== 0 ? gdjs.Level_321Code.GDPlayer1Objects2[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3, "", 0);
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Level_321Code.GDPlayer1Objects1});
gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDcheckpointObjects1Objects = Hashtable.newFrom({"checkpoint": gdjs.Level_321Code.GDcheckpointObjects1});
gdjs.Level_321Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("checkpoint"), gdjs.Level_321Code.GDcheckpointObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects, gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDcheckpointObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDcheckpointObjects1 */
{runtimeScene.getScene().getVariables().get("checkpoint").getChild("X").setNumber((( gdjs.Level_321Code.GDcheckpointObjects1.length === 0 ) ? 0 :gdjs.Level_321Code.GDcheckpointObjects1[0].getPointY("")));
}{runtimeScene.getScene().getVariables().get("checkpoint").getChild("Y").setNumber((( gdjs.Level_321Code.GDcheckpointObjects1.length === 0 ) ? 0 :gdjs.Level_321Code.GDcheckpointObjects1[0].getPointX("")));
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Level_321Code.GDPlayer1Objects1});
gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDBearTrapObjects1Objects = Hashtable.newFrom({"BearTrap": gdjs.Level_321Code.GDBearTrapObjects1});
gdjs.Level_321Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BearTrap"), gdjs.Level_321Code.GDBearTrapObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects, gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDBearTrapObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("checkpointX")) + 40,gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("checkpointY")) + 610);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "3e31e2ca264115c4b4bb14228120aa89f309a9ca9db8953e575066921338995d_Hard_Run_01.wav", false, 100, 1);
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Level_321Code.GDPlayer1Objects1});
gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDStrawberryObjects1Objects = Hashtable.newFrom({"Strawberry": gdjs.Level_321Code.GDStrawberryObjects1});
gdjs.Level_321Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Strawberry"), gdjs.Level_321Code.GDStrawberryObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects, gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDStrawberryObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDStrawberryObjects1 */
gdjs.copyArray(runtimeScene.getObjects("WoodGreenBar"), gdjs.Level_321Code.GDWoodGreenBarObjects1);
{for(var i = 0, len = gdjs.Level_321Code.GDStrawberryObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDStrawberryObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "de880373f1471d9c0960e160c52e1ab6b0e50c737652c6d7d53490b4420c7089_coin.aac", false, 100, 1);
}{for(var i = 0, len = gdjs.Level_321Code.GDWoodGreenBarObjects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDWoodGreenBarObjects1[i].SetValue(gdjs.Level_321Code.GDWoodGreenBarObjects1[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Level_321Code.GDPlayer1Objects1});
gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDWaterFlatBrightDesatObjects1Objects = Hashtable.newFrom({"WaterFlatBrightDesat": gdjs.Level_321Code.GDWaterFlatBrightDesatObjects1});
gdjs.Level_321Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Level_321Code.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("WaterFlatBrightDesat"), gdjs.Level_321Code.GDWaterFlatBrightDesatObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDPlayer1Objects1Objects, gdjs.Level_321Code.mapOfGDgdjs_9546Level_9595321Code_9546GDWaterFlatBrightDesatObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDPlayer1Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDPlayer1Objects1[k] = gdjs.Level_321Code.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDPlayer1Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level_321Code.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.Level_321Code.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Level_321Code.GDPlayer1Objects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("checkpointX")) + 40,gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("checkpointY")) + 610);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "2cef9d929a123824bf11eedfcb361b10353e41bfec7f9d2998a684081204e375_WaterV2_Walk_05.wav", false, 100, 1);
}}

}


};gdjs.Level_321Code.eventsList7 = function(runtimeScene) {

};gdjs.Level_321Code.eventsList8 = function(runtimeScene) {

{


gdjs.Level_321Code.eventsList0(runtimeScene);
}


{


gdjs.Level_321Code.eventsList1(runtimeScene);
}


{


gdjs.Level_321Code.eventsList2(runtimeScene);
}


{


gdjs.Level_321Code.eventsList3(runtimeScene);
}


{


gdjs.Level_321Code.eventsList4(runtimeScene);
}


{


gdjs.Level_321Code.eventsList5(runtimeScene);
}


{


gdjs.Level_321Code.eventsList6(runtimeScene);
}


{


gdjs.Level_321Code.eventsList7(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("WoodGreenBar"), gdjs.Level_321Code.GDWoodGreenBarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level_321Code.GDWoodGreenBarObjects1.length;i<l;++i) {
    if ( gdjs.Level_321Code.GDWoodGreenBarObjects1[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 22 ) {
        isConditionTrue_0 = true;
        gdjs.Level_321Code.GDWoodGreenBarObjects1[k] = gdjs.Level_321Code.GDWoodGreenBarObjects1[i];
        ++k;
    }
}
gdjs.Level_321Code.GDWoodGreenBarObjects1.length = k;
if (isConditionTrue_0) {
}

}


};

gdjs.Level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_321Code.GDGroundObjects1.length = 0;
gdjs.Level_321Code.GDGroundObjects2.length = 0;
gdjs.Level_321Code.GDGroundObjects3.length = 0;
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects1.length = 0;
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects2.length = 0;
gdjs.Level_321Code.GDGround_9595Right_9595EdgeObjects3.length = 0;
gdjs.Level_321Code.GDGroundLeftEdgeObjects1.length = 0;
gdjs.Level_321Code.GDGroundLeftEdgeObjects2.length = 0;
gdjs.Level_321Code.GDGroundLeftEdgeObjects3.length = 0;
gdjs.Level_321Code.GDGrass_95951Objects1.length = 0;
gdjs.Level_321Code.GDGrass_95951Objects2.length = 0;
gdjs.Level_321Code.GDGrass_95951Objects3.length = 0;
gdjs.Level_321Code.GDGrassRightEdgeObjects1.length = 0;
gdjs.Level_321Code.GDGrassRightEdgeObjects2.length = 0;
gdjs.Level_321Code.GDGrassRightEdgeObjects3.length = 0;
gdjs.Level_321Code.GDGrassLeftEdgeObjects1.length = 0;
gdjs.Level_321Code.GDGrassLeftEdgeObjects2.length = 0;
gdjs.Level_321Code.GDGrassLeftEdgeObjects3.length = 0;
gdjs.Level_321Code.GDGroundBaseObjects1.length = 0;
gdjs.Level_321Code.GDGroundBaseObjects2.length = 0;
gdjs.Level_321Code.GDGroundBaseObjects3.length = 0;
gdjs.Level_321Code.GDPlayer1Objects1.length = 0;
gdjs.Level_321Code.GDPlayer1Objects2.length = 0;
gdjs.Level_321Code.GDPlayer1Objects3.length = 0;
gdjs.Level_321Code.GDNarrowLadderObjects1.length = 0;
gdjs.Level_321Code.GDNarrowLadderObjects2.length = 0;
gdjs.Level_321Code.GDNarrowLadderObjects3.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects1.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects2.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesat1Objects3.length = 0;
gdjs.Level_321Code.GDSky_9595BaseObjects1.length = 0;
gdjs.Level_321Code.GDSky_9595BaseObjects2.length = 0;
gdjs.Level_321Code.GDSky_9595BaseObjects3.length = 0;
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects1.length = 0;
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects2.length = 0;
gdjs.Level_321Code.GDDarkDirt_9595BaseObjects3.length = 0;
gdjs.Level_321Code.GDHealthObjects1.length = 0;
gdjs.Level_321Code.GDHealthObjects2.length = 0;
gdjs.Level_321Code.GDHealthObjects3.length = 0;
gdjs.Level_321Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Level_321Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Level_321Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.Level_321Code.GDPixelHeartBarObjects1.length = 0;
gdjs.Level_321Code.GDPixelHeartBarObjects2.length = 0;
gdjs.Level_321Code.GDPixelHeartBarObjects3.length = 0;
gdjs.Level_321Code.GDcheckpointObjects1.length = 0;
gdjs.Level_321Code.GDcheckpointObjects2.length = 0;
gdjs.Level_321Code.GDcheckpointObjects3.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects1.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects2.length = 0;
gdjs.Level_321Code.GDWaterFlatBrightDesatObjects3.length = 0;
gdjs.Level_321Code.GDStrawberryObjects1.length = 0;
gdjs.Level_321Code.GDStrawberryObjects2.length = 0;
gdjs.Level_321Code.GDStrawberryObjects3.length = 0;
gdjs.Level_321Code.GDBearTrapObjects1.length = 0;
gdjs.Level_321Code.GDBearTrapObjects2.length = 0;
gdjs.Level_321Code.GDBearTrapObjects3.length = 0;
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects1.length = 0;
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects2.length = 0;
gdjs.Level_321Code.GDEmptyCloudBackgroundObjects3.length = 0;
gdjs.Level_321Code.GDBackgroundMountainsObjects1.length = 0;
gdjs.Level_321Code.GDBackgroundMountainsObjects2.length = 0;
gdjs.Level_321Code.GDBackgroundMountainsObjects3.length = 0;
gdjs.Level_321Code.GDCloudsObjects1.length = 0;
gdjs.Level_321Code.GDCloudsObjects2.length = 0;
gdjs.Level_321Code.GDCloudsObjects3.length = 0;
gdjs.Level_321Code.GDClouds2Objects1.length = 0;
gdjs.Level_321Code.GDClouds2Objects2.length = 0;
gdjs.Level_321Code.GDClouds2Objects3.length = 0;
gdjs.Level_321Code.GDWoodGreenBarObjects1.length = 0;
gdjs.Level_321Code.GDWoodGreenBarObjects2.length = 0;
gdjs.Level_321Code.GDWoodGreenBarObjects3.length = 0;

gdjs.Level_321Code.eventsList8(runtimeScene);

return;

}

gdjs['Level_321Code'] = gdjs.Level_321Code;
