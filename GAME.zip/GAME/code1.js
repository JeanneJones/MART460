gdjs.TeleportCode = {};
gdjs.TeleportCode.GDGroundObjects1= [];
gdjs.TeleportCode.GDGroundObjects2= [];
gdjs.TeleportCode.GDGround_9595Right_9595EdgeObjects1= [];
gdjs.TeleportCode.GDGround_9595Right_9595EdgeObjects2= [];
gdjs.TeleportCode.GDGroundLeftEdgeObjects1= [];
gdjs.TeleportCode.GDGroundLeftEdgeObjects2= [];
gdjs.TeleportCode.GDGrass_95951Objects1= [];
gdjs.TeleportCode.GDGrass_95951Objects2= [];
gdjs.TeleportCode.GDGrassRightEdgeObjects1= [];
gdjs.TeleportCode.GDGrassRightEdgeObjects2= [];
gdjs.TeleportCode.GDGrassLeftEdgeObjects1= [];
gdjs.TeleportCode.GDGrassLeftEdgeObjects2= [];
gdjs.TeleportCode.GDGroundBaseObjects1= [];
gdjs.TeleportCode.GDGroundBaseObjects2= [];
gdjs.TeleportCode.GDNewSpriteObjects1= [];
gdjs.TeleportCode.GDNewSpriteObjects2= [];
gdjs.TeleportCode.GDYou_9595WonObjects1= [];
gdjs.TeleportCode.GDYou_9595WonObjects2= [];
gdjs.TeleportCode.GDRetryObjects1= [];
gdjs.TeleportCode.GDRetryObjects2= [];
gdjs.TeleportCode.GDGreenButtonObjects1= [];
gdjs.TeleportCode.GDGreenButtonObjects2= [];
gdjs.TeleportCode.GDNewTiledSpriteObjects1= [];
gdjs.TeleportCode.GDNewTiledSpriteObjects2= [];
gdjs.TeleportCode.GDNewSprite2Objects1= [];
gdjs.TeleportCode.GDNewSprite2Objects2= [];


gdjs.TeleportCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreenButton"), gdjs.TeleportCode.GDGreenButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TeleportCode.GDGreenButtonObjects1.length;i<l;++i) {
    if ( gdjs.TeleportCode.GDGreenButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TeleportCode.GDGreenButtonObjects1[k] = gdjs.TeleportCode.GDGreenButtonObjects1[i];
        ++k;
    }
}
gdjs.TeleportCode.GDGreenButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level 1", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "e8e669cf8c921f2f3beca9768b09ed48ce1d60259e67a37d5c1a31f042ae4352_18 - i beat the final dungeon and all i got was this lousy triangle.aac", false, 20, 1);
}}

}


};

gdjs.TeleportCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TeleportCode.GDGroundObjects1.length = 0;
gdjs.TeleportCode.GDGroundObjects2.length = 0;
gdjs.TeleportCode.GDGround_9595Right_9595EdgeObjects1.length = 0;
gdjs.TeleportCode.GDGround_9595Right_9595EdgeObjects2.length = 0;
gdjs.TeleportCode.GDGroundLeftEdgeObjects1.length = 0;
gdjs.TeleportCode.GDGroundLeftEdgeObjects2.length = 0;
gdjs.TeleportCode.GDGrass_95951Objects1.length = 0;
gdjs.TeleportCode.GDGrass_95951Objects2.length = 0;
gdjs.TeleportCode.GDGrassRightEdgeObjects1.length = 0;
gdjs.TeleportCode.GDGrassRightEdgeObjects2.length = 0;
gdjs.TeleportCode.GDGrassLeftEdgeObjects1.length = 0;
gdjs.TeleportCode.GDGrassLeftEdgeObjects2.length = 0;
gdjs.TeleportCode.GDGroundBaseObjects1.length = 0;
gdjs.TeleportCode.GDGroundBaseObjects2.length = 0;
gdjs.TeleportCode.GDNewSpriteObjects1.length = 0;
gdjs.TeleportCode.GDNewSpriteObjects2.length = 0;
gdjs.TeleportCode.GDYou_9595WonObjects1.length = 0;
gdjs.TeleportCode.GDYou_9595WonObjects2.length = 0;
gdjs.TeleportCode.GDRetryObjects1.length = 0;
gdjs.TeleportCode.GDRetryObjects2.length = 0;
gdjs.TeleportCode.GDGreenButtonObjects1.length = 0;
gdjs.TeleportCode.GDGreenButtonObjects2.length = 0;
gdjs.TeleportCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.TeleportCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.TeleportCode.GDNewSprite2Objects1.length = 0;
gdjs.TeleportCode.GDNewSprite2Objects2.length = 0;

gdjs.TeleportCode.eventsList0(runtimeScene);

return;

}

gdjs['TeleportCode'] = gdjs.TeleportCode;
